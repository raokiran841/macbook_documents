package bookmyshow;

public class Seat {
    private long seatId;
    private long roomId;
    private volatile boolean available = false;
    public Seat(long seatId, long roomId) {
        this.seatId = seatId;
        this.roomId = roomId;
    }
    public long getSeatId() {
        return seatId;
    }
    public void setSeatId(long seatId) {
        this.seatId = seatId;
    }
    public long getRoomId() {
        return roomId;
    }
    public void setRoomId(long roomId) {
        this.roomId = roomId;
    }
    public boolean isAvailable() {
        return available;
    }
    public void setAvailable(boolean available) {
        this.available = available;
    }

}
