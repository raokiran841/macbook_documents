package bookmyshow;

import java.util.HashSet;
import java.util.Set;

public class App {
    private static Set<Seat> seats = new HashSet<>();
    public static void main(String[] args) {
        App app = new App();
        app.startBooking(seats);
    }

    private void startBooking(Set<Seat> seats){
        System.out.println("select a seat:");
        displaySeats();
    }

    private void displaySeats(){
        int i = 1;
        for(Seat seat: seats){
            System.out.print(seat.getSeatId()+" ");
            if(i%5 == 0) System.out.println();
        }
    }
}
